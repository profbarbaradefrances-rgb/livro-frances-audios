// Smooth scroll with offset for navigation links
document.addEventListener('DOMContentLoaded', function() {
    // Highlight active page based on scroll position
    const audioPages = document.querySelectorAll('.audio-page');
    const pageLinks = document.querySelectorAll('.page-link');
    
    // Function to update active link
    function updateActiveLink() {
        let currentPage = '';
        
        audioPages.forEach(page => {
            const pageTop = page.offsetTop - 150;
            if (window.scrollY >= pageTop) {
                currentPage = page.getAttribute('id');
            }
        });
        
        pageLinks.forEach(link => {
            link.classList.remove('active');
            if (link.getAttribute('href').substring(1) === currentPage) {
                link.classList.add('active');
            }
        });
    }
    
    // Update active link on scroll
    window.addEventListener('scroll', updateActiveLink);
    
    // Smooth scroll behavior for all internal links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            e.preventDefault();
            const targetId = this.getAttribute('href').substring(1);
            const targetElement = document.getElementById(targetId);
            
            if (targetElement) {
                const offsetTop = targetElement.offsetTop - 100;
                window.scrollTo({
                    top: offsetTop,
                    behavior: 'smooth'
                });
            }
        });
    });
    
    // Add visual feedback for audio players
    const audioPlayers = document.querySelectorAll('audio');
    
    audioPlayers.forEach(audio => {
        audio.addEventListener('play', function() {
            // Pause other audio players when one starts
            audioPlayers.forEach(otherAudio => {
                if (otherAudio !== audio) {
                    otherAudio.pause();
                }
            });
            
            // Add playing class to parent container
            this.closest('.audio-player').classList.add('playing');
        });
        
        audio.addEventListener('pause', function() {
            this.closest('.audio-player').classList.remove('playing');
        });
        
        audio.addEventListener('ended', function() {
            this.closest('.audio-player').classList.remove('playing');
        });
    });
    
    // Add animation to page cards on scroll
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };
    
    const observer = new IntersectionObserver(function(entries) {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
            }
        });
    }, observerOptions);
    
    // Observe all audio page cards
    audioPages.forEach(page => {
        page.style.opacity = '0';
        page.style.transform = 'translateY(20px)';
        page.style.transition = 'opacity 0.5s ease, transform 0.5s ease';
        observer.observe(page);
    });
    
    // Back to top button (appears after scrolling)
    const backToTopButton = createBackToTopButton();
    
    function createBackToTopButton() {
        const button = document.createElement('button');
        button.innerHTML = '↑';
        button.className = 'back-to-top';
        button.setAttribute('aria-label', 'Voltar ao topo');
        document.body.appendChild(button);
        
        button.addEventListener('click', function() {
            window.scrollTo({
                top: 0,
                behavior: 'smooth'
            });
        });
        
        return button;
    }
    
    // Show/hide back to top button
    window.addEventListener('scroll', function() {
        if (window.scrollY > 500) {
            backToTopButton.classList.add('visible');
        } else {
            backToTopButton.classList.remove('visible');
        }
    });
    
    // Check if URL has hash and scroll to it
    if (window.location.hash) {
        setTimeout(() => {
            const targetElement = document.querySelector(window.location.hash);
            if (targetElement) {
                const offsetTop = targetElement.offsetTop - 100;
                window.scrollTo({
                    top: offsetTop,
                    behavior: 'smooth'
                });
            }
        }, 100);
    }
    
    // Add keyboard navigation support
    document.addEventListener('keydown', function(e) {
        // Press 'Home' to go to top
        if (e.key === 'Home') {
            e.preventDefault();
            window.scrollTo({ top: 0, behavior: 'smooth' });
        }
        
        // Press 'End' to go to bottom
        if (e.key === 'End') {
            e.preventDefault();
            window.scrollTo({ 
                top: document.body.scrollHeight, 
                behavior: 'smooth' 
            });
        }
    });
    
    // Log when page is ready
    console.log('🎨 Mon Petit Livre de Coloriage - Site carregado com sucesso!');
    console.log('📚 Total de páginas:', audioPages.length);
});